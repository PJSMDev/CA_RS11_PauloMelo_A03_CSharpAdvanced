﻿namespace D21_SOLID_05_DIP
{

    public interface INameFormatter
    {

        string FormatName(Person person);

    }

}
